$(document).ready(function () {
    $(".purpleToFuchsia").click(function(){
       $(".purple").css({'background-color': 'fuchsia'});
    });
});

$(document).ready(function () {
    $(".toggleGreenGrey").click(function(){
        if($(".green").attr('style') == 'background-color : grey')
            $(".green").attr({'style':'background-color : green'});
        else
            $(".green").attr({'style':'background-color : grey'});
    });
});

$(document).ready(function () {
    $(".toggleGreenGrey2").click(function(){
        $('.green').toggleClass('grey');
    });
});

$(document).ready(function () {
    $(".switchBoxes").click(function(){
        var box1 = $('.red');
        var box2 = $('.blue');
        box1.attr({'class':'blue'});
        box2.attr({'class':'red'});
        //box1.removeAttr({'class':'red'});
        //box2.removeAttr({'class':'blue'});
    });
});

$(document).ready(function () {
    $(".insertText").click(function(){
        var $newParagraph = $("<div class='white'> sometext </div>");
        $('.purple').prepend($newParagraph);
    });
});

var ok = 0,
    x;

$(document).ready(function () {
    $('.colors div').click(function () {


        if(ok === 0)
        {
            ok = 1;
            x = $(this).attr('class');
            console.log(x);
        }
        else
        {
            ok = 0;

            var box1 = $(this).attr('class');
            var box2 = x;
            console.log(box1);
            console.log(box2);
            $('.'+box1).first().attr({'class':box2});
            $('.'+box2).first().attr({'class':box1});
            x=null;
        }
    });
});







